# Pyrogram setup
API_ID = "27236622"  # Replace this API ID with your actual API ID
API_HASH =  "e595bde34be63aff6b9f20a31871217d"  # Replace this API HASH with your actual API HASH
BOT_TOKEN = "7927308475:AAHExNXLZwEKue6yhJWSunMTJ7CiWI0EU2M"  # Replace this BOT_TOKEN

# Admin IDs
ADMIN_IDS = [6176341148]


DEFAULT_LIMIT = 10000
ADMIN_LIMIT = 50000